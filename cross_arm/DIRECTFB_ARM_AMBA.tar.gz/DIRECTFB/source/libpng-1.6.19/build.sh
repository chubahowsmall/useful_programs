#!/bin/bash

export CPPFLAGS="-I/media/workarea/IronMan/RING/ambarella/prebuild/third-party/armv7-a-hf/zlib/include"
export LDFLAGS="-L/media/workarea/IronMan/RING/ambarella/out/s2lm_ironman/fakeroot/usr/lib"


./configure --host=arm-linux --build=x86_64 --disable-static --enable-shared --prefix=/opt/arm CC=arm-linux-gnueabihf-gcc AR=arm-linux-gnueabihf-ar NM=arm-linux-gnueabihf-nm RANLIB=arm-linux-gnueabihf-ranlib --with-sysroot=/media/workarea/IronMan/RING/ambarella/out/s2lm_ironman/fakeroot

