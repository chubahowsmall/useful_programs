#!/bin/bash

./configure --host=arm-linux-gnueabihf		\
	--prefix=/opt/arm						\
	CFLAGS="-I/opt/arm/include"				\
	CFLAGS="-I/opt/arm/include/directfb"	\
	LDFLAGS="-L/opt/arm/lib"				\
	FREETYPE_CFLAGS="-I/opt/arm/include/freetype2"	\
	LIBPNG_LIBS="-L/opt/arm/lib -lpng"		\
	LIBPNG_CFLAGS="-I/opt/arm/include"		\
	FREETYPE_LIBS="-L/opt/arm/lib -lfreetype"	\
	DIRECTFB_CFLAGS="-I/opt/arm/include/directfb"	\
	DIRECTFB_CFLAGS="-I/opt/arm/include/directfb-internal"	\
	DIRECTFB_LDFLAGS="-L/opt/arm/lib -ldirectfb"	\
	LIBS="/media/workarea/IronMan/RING/ambarella/out/s2lm_ironman/fakeroot/lib/libstdc++.so.6"	\
	PKG_CONFIG_PATH="/opt/arm/lib/pkgconfig"


