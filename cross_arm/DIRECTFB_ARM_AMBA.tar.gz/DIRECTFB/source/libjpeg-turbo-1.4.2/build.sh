#!/bin/bash

./configure --host=arm-linux			\
			--build=x86_64				\
			--prefix=/opt/arm			\
			--enable-shared				\
			--disable-static			\
			--with-sysroot=/media/workarea/IronMan/RING/ambarella/out/s2lm_ironman/fakeroot	\
			--with-jpeg7				\
			--with-jpeg8				\
			--enable-rpath				\
			CC=arm-linux-gnueabihf-gcc	\
			AR=arm-linux-gnueabihf-ar	\
			NM=arm-linux-gnueabihf-nm	\
			RANLIB=arm-linux-gnueabihf-ranlib
